export interface ProductColor {
  id: string;
  name: string;
  hex: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  images: string[];
  colors: ProductColor[];
  isBestSeller: boolean;
  stock: number;
  createdAt: number;
  updatedAt: number;
}

export type OrderStatus =
  | "pending"
  | "confirmed"
  | "preparing"
  | "delivered"
  | "cancelled";

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  pending: "قيد الانتظار",
  confirmed: "تم التأكيد",
  preparing: "قيد التجهيز",
  delivered: "تم التوصيل",
  cancelled: "ملغي",
};

export interface OrderItem {
  productId: string;
  productName: string;
  productImage: string;
  selectedColor: string;
  price: number;
  quantity: number;
}

export interface Order {
  id: string;
  items: OrderItem[];
  totalPrice: number;
  customerName: string;
  phone: string;
  governorate: string;
  address: string;
  notes: string;
  status: OrderStatus;
  createdAt: number;
}

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  image: string;
  selectedColor: string;
  quantity: number;
  maxStock: number;
}

export interface StoreSettings {
  storeName: string;
  logoUrl: string;
  announcementBar: string;
  announcementEnabled: boolean;
}

export const IRAQ_GOVERNORATES = [
  "بغداد",
  "البصرة",
  "نينوى",
  "أربيل",
  "النجف",
  "كربلاء",
  "الأنبار",
  "ديالى",
  "ذي قار",
  "واسط",
  "ميسان",
  "المثنى",
  "القادسية",
  "بابل",
  "صلاح الدين",
  "كركوك",
  "دهوك",
  "السليمانية",
];

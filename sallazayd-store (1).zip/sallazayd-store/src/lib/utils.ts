export function formatPrice(price: number): string {
  return new Intl.NumberFormat("ar-IQ").format(price) + " د.ع";
}

export function formatDate(timestamp: number): string {
  return new Intl.DateTimeFormat("ar-IQ", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(timestamp));
}

export function slugifyId(): string {
  return (
    Date.now().toString(36) + Math.random().toString(36).slice(2, 8)
  );
}
